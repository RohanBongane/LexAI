﻿import traceback
from app import create_app
from services.rag_service import answer_question
from models.database_models import User

app = create_app()
with app.app_context():
    try:
        user = User.query.first()
        if not user:
            print("No users in DB")
        else:
            print(f"Testing with user: {user.email}")
            result = answer_question(
                user_id=user.id,
                question="What is contract?",
                document_id=None
            )
            print("SUCCESS:")
            print(result)
    except Exception as e:
        print("ERROR:")
        traceback.print_exc()
